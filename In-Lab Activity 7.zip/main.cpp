#include "Triangle.h"
#include "Square.h"
#include <iostream>

using namespace std;

int main() {
  
   //Do not modify
  
   return 0;
} 